PhysioVertex Employee Management App — final configured Android starter

Clinic:
Shop No. 14, Ruparel Millenia, Jerbai Wadia Rd, Parel East, Parel, Mumbai, Maharashtra 400012.

Features in this starter:
- Employee login UI
- GPS attendance check-in/check-out
- 150 m clinic geofence
- Attendance, salary and leave entry points

Important:
- The clinic coordinates in MainActivity.kt are approximate and must be verified against the exact Google Maps pin.
- This is a buildable starter project, not a production backend.
- Production needs secure server/database, Admin authentication, role-based access, server-side timestamps, fresh location readings, employee records, salary calculation, leave approvals, reports and audit logs.
