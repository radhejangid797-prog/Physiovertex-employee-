package com.physiovertex.app

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationManager
import android.view.Gravity
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    // PhysioVertex: Shop No. 14, Ruparel Millenia, Jerbai Wadia Rd, Parel East, Parel, Mumbai 400012
    // Approximate coordinates; verify exact pin before production deployment.
    private val clinicLat = 18.9995
    private val clinicLng = 72.8375
    private val radiusMeters = 150f

    private var inTime: String? = null
    private var outTime: String? = null
    private lateinit var status: TextView
    private lateinit var times: TextView

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); login() }

    private fun login() {
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(42,42,42,42); setBackgroundColor(Color.rgb(245,250,252)) }
        val title=TextView(this).apply { text="PHYSIOVERTEX"; textSize=30f; gravity=Gravity.CENTER; setTextColor(Color.rgb(23,107,135)) }
        val sub=TextView(this).apply { text="Employee Management"; textSize=18f; gravity=Gravity.CENTER; setPadding(0,10,0,30) }
        val id=EditText(this).apply { hint="Employee ID" }
        val pw=EditText(this).apply { hint="Password"; inputType=0x81 }
        val login=Button(this).apply { text="LOGIN" }
        login.setOnClickListener { dashboard(id.text.toString().ifBlank{"Employee"}) }
        box.addView(title); box.addView(sub); box.addView(id); box.addView(pw); box.addView(login); setContentView(box)
    }

    private fun dashboard(name:String) {
        val scroll=ScrollView(this)
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(26,26,26,26); setBackgroundColor(Color.rgb(245,250,252)) }
        val head=TextView(this).apply { text="PHYSIOVERTEX\nEmployee Dashboard"; textSize=25f; setTextColor(Color.rgb(23,107,135)); setPadding(0,0,0,18) }
        val hi=TextView(this).apply { text="Welcome, $name 👋"; textSize=20f; setPadding(0,0,0,14) }
        status=TextView(this).apply { text="Today's Attendance\nLocation verification required"; textSize=18f; setPadding(18,18,18,18); setBackgroundColor(Color.WHITE) }
        times=TextView(this).apply { text="In: —\nOut: —"; textSize=16f; setPadding(18,18,18,18) }
        val cin=Button(this).apply { text="🟢 CHECK IN" }
        val cout=Button(this).apply { text="🔴 CHECK OUT" }
        cin.setOnClickListener { gps("IN") }; cout.setOnClickListener { gps("OUT") }
        val a=Button(this).apply { text="📅 Attendance History" }
        val s=Button(this).apply { text="💰 Salary Details" }
        val l=Button(this).apply { text="🏖️ Leave Request" }
        a.setOnClickListener { Toast.makeText(this,"Monthly attendance will appear here after database connection.",Toast.LENGTH_SHORT).show() }
        s.setOnClickListener { Toast.makeText(this,"Salary and payslips will appear here after database connection.",Toast.LENGTH_SHORT).show() }
        l.setOnClickListener { Toast.makeText(this,"Leave request screen will appear here after database connection.",Toast.LENGTH_SHORT).show() }
        box.addView(head); box.addView(hi); box.addView(status); box.addView(times); box.addView(cin); box.addView(cout); box.addView(a); box.addView(s); box.addView(l)
        scroll.addView(box); setContentView(scroll)
    }

    private fun gps(action:String) {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),77)
            Toast.makeText(this,"Allow location permission, then tap again.",Toast.LENGTH_LONG).show(); return
        }
        val lm=getSystemService(LOCATION_SERVICE) as LocationManager
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) { Toast.makeText(this,"Please turn on GPS/location.",Toast.LENGTH_LONG).show(); return }
        val loc=try { lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) } catch(e:SecurityException){null}
        if (loc==null) { Toast.makeText(this,"Current location unavailable. Try again.",Toast.LENGTH_LONG).show(); return }
        val d=FloatArray(1); Location.distanceBetween(loc.latitude,loc.longitude,clinicLat,clinicLng,d)
        if (d[0] > radiusMeters) { Toast.makeText(this,"Attendance blocked: outside clinic area (${d[0].toInt()} m).",Toast.LENGTH_LONG).show(); return }
        val t=SimpleDateFormat("dd MMM yyyy, hh:mm a",Locale.getDefault()).format(Date())
        if(action=="IN" && inTime==null){inTime=t;status.text="Today's Attendance\n✅ Checked In";times.text="In: $inTime\nOut: —"}
        else if(action=="OUT" && inTime!=null && outTime==null){outTime=t;status.text="Today's Attendance\n✅ Checked Out";times.text="In: $inTime\nOut: $outTime"}
        else Toast.makeText(this,"Attendance action not available.",Toast.LENGTH_SHORT).show()
    }
}
